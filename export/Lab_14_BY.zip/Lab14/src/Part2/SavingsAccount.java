package Part2;

public class SavingsAccount extends Account{	
	//create a constructor that takes a parameter of type long called amt 
	SavingsAccount(long amt){
		//call the constructor of the super class with parameters "saving" and amt 
		//use super("saving", amt)
		super("saving", amt);
		
	}
}
