package Part1;

public class Character {
	
	public void walk() {
		System.out.println("tap tap tap");
	}
	
	public void talk() {
		System.out.println("You can't defeat me!");
	}

	public void attack() {
		System.out.println("Ah!");
	}
	
	public void die() {
		System.out.println("You have bested me.");
	}
}
