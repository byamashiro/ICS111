package Part1;

class Basilisk extends Enemy {
	public void walk() {
		System.out.println("slither slither");
	}
}
