package Part1;

class Warrior extends Hero {
	
}
