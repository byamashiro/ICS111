package Part1;

class Wizard extends Hero {
	public void attack() {
		System.out.println("Alacazam");
	}
}
