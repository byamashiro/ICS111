package Part1;

class Hero extends Character {
	public void talk() {
		System.out.println("Prepare to die");
	}
}
