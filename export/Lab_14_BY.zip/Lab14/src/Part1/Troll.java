package Part1;

class Troll extends Enemy {
	public void die() {
		System.out.println("Roaaarrr...");
	}
}
