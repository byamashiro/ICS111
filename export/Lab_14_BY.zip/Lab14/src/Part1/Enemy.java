package Part1;

class Enemy extends Character {

}
