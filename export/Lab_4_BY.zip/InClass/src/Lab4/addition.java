package Lab4;

public class addition {

	static int add(int a, int b) {
		int p;
		p = a + b;
		return(p);
	}

	public static void main(String[] args) {
		int sum;
		sum = add(4, 3);
		
		System.out.println("The sum of the two integers is: " + sum);

	}

}
