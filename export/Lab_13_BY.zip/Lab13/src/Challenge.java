import java.io.FileNotFoundException;

import java.io.FileReader;
import java.util.Scanner;

public class Challenge {
	public static void main(String[] args) throws FileNotFoundException {
		//Read the newly created “map.txt” file into a scanner.
		
		//Read the height and width values from map.txt into two variables called columns and rows
		
		
		
		//Initialize an EZ map based on the columns and rows, and also the tile size (hint: look at the MineMap code)
		
		
		//Initialize a 2D char array with size equal to columns and rows 
		//you can decide on columns or rows first, as you long as you stay consistent
		
		
		// declare a String variable
		
		
		//
		//Using a nested for loop, iterate through the 2D array and add the corresponding letters from map.txt
		//in the outer for loop, you use the next() method to scan in a whole line to the string variable
		
		
			//in the inner for loop, use the String.charAt() method to add individual chars from the String to the 2D array
			//pass the inner variable into the charAt() method
			
		
		
		
		//Using another nested for loop, add a tile image to the EZ map based on each char in the 2D array
		//use a switch to do this
		
		
		
	}
}
