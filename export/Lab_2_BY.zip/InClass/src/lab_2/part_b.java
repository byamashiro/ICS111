package lab_2;
import java.awt.Color;


public class part_b {

	public static void main(String[] args) {
		
			
		// ======= Part B
		int val = 9 ; // 9, 8, 13
		
		if  ( val % 2 == 0) {
			System.out.println(val + " is divisible by 2");
		} else {
			if ( val % 3 == 0 ) { // val % 3 works here as well
				System.out.println(val + " is divisible by 3");
			} else {
				System.out.println("your number is " + val);
			}
		}
		
		
			
		/* 
		int[] val = {9, 8, 13};
		
		for (int i = 0; i < val.length; i++) {
			if ((val[i] / 2)  % 2 == 0) {
				System.out.println(val + " is divisible by 2");
			} else if
		}
		*/
			
			
			
		
		}
		
		
		
		
		
		

	}

