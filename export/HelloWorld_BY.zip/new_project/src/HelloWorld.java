import java.awt.Color;

public class HelloWorld {

	public static void main(String[] args) {
		//System.out.println("Hello World"); // without EZ 
		
		EZ.initialize(200, 200);
		EZ.addText(100,  100, "Hello World", Color.BLACK);
		// TODO Auto-generated method stub

	}

}
