
public class Part1 {

	public static void main(String[] args) {
		
		// for each row...
		for(int i = 0; i < 5; i++) {
			
			// print a row of x's
			for(int j = 0; j < 5; j++) {
				if (j >= 1+i) { // if the column number is greater or equal to 1+i then set the character to "x"
					System.out.print("x");
				} else if (j == i) { // for the columns that equal the column number, set the character to "-"
					System.out.print("-");
				} else if (j >= 1-i) {
					System.out.print("#");
				}
			}
			
			// skip a line
			System.out.println();
			
		}
		
	}
	
}
