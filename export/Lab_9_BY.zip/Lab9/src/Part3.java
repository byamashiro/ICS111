
public class Part3 {

	public static void main(String[] args) {
		Pokemon[] belt = new Pokemon[4]; // initialize belt of amount of Pokemon, 4
		
		belt[0] = new Pokemon("Pikachu"); // make a belt object with Pikachu
		belt[1] = new Pokemon("Squirtle");
		belt[2] = new Pokemon("Bulbasaur");
		belt[3] = new Pokemon("Charmander");
		
		int i=0;
		while (i < 4) { // for all the pokemon in the belt, have them talk as they are set to talk
			belt[i].talk(); // have the pokemon say its name 3 times
			i++;
		}
		
	}
	
}
