import java.awt.Color;

public class Tile {

	public EZRectangle square;
	
	public Tile(int x, int y, int dim) {
		// place a tile
		int xPos = x*dim + dim/2;
		int yPos = y*dim + dim/2;
		square = EZ.addRectangle(xPos, yPos, dim, dim, Color.BLACK, true);
	}
	
	public void update() {
		
		// if clicked, then hide
		if( EZInteraction.wasMouseLeftButtonReleased() ) {
			int mouseX = EZInteraction.getXMouse();
			int mouseY = EZInteraction.getYMouse();
			if( EZ.isElementAtPoint(mouseX, mouseY, square) ) {
				square.hide();
			}
		}
		
	}
	
}
