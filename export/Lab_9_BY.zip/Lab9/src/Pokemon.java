import java.awt.Color;

public class Pokemon {
	String name;
	
	public Pokemon(String n) { // make a pokemon object with a input string
		// place a tile
		name = n;
		System.out.println("Go " + name + "!"); // when a pokemon is initialized, have it say its name
	}
	
	public void talk() {
		System.out.println(name+ " " + name + " " + name); // when using .talk(), have it say its name 3 times
	}
		
}
