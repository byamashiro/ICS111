import java.awt.Color;

public class Part2 {

	static EZImage surprise;
	
	public static void main(String[] args) {

		EZ.initialize(500, 500);
		
		// initialize screen with hidden surprise
		init();
		
		// tile vars
		Tile[] tiles = new Tile[25];
		int t = 0;
		
		// initialize tiles
		for(int y=0; y<5; y++) {
			for(int x=0; x<5; x++) {
				tiles[t] = new Tile(x, y, 100);
				t++; // increment the tile to load every tile into the array
			}
		}
		
		/*
		for (int i=0; i<25; i++) {
			System.out.println(tiles[i]);
		}
		*/
		// position the surprise behind the tiles
		position();
		
		while(true) {
			
			for (int i=0; i<25; i++) { // for all the tiles in the array that has been populated...
				tiles[i].update(); // use tiles to update
			}
			// Golly Gee! Why is this only updating the bottom-right tile?
			// tiles[t].update();
			
			EZ.refreshScreen();
		}
		
	}
	
	public static void init() {
		// initialize a surprise off the screen
		surprise = EZ.addImage("surprise.png", 1000, 250);
		surprise.scaleTo(7);
	}
	
	public static void position() {
		// place in center
		surprise.translateTo(250, 250);
	}
	
}
