
public class Player {

	public int x;
	
	public void update() {
		// for i = 0 to length of bads array in Part2.java
		for (int i=0; i<Part2.bads.length;i++) {
			System.out.println(Part2.bads[i].x);// println bads[i].x
		}
	}
	
}
