
public class RacingBug {
	// Member variables
	EZImage img;
	char move_key;
	
	// Constructor
	public RacingBug(String file_name, int x, int y, char key){
		img = EZ.addImage(file_name, x, y);
		move_key = key;
	}
	
	// Member functions
	public void getX() {
		img.getXCenter();
	}
	public void getY() {
		img.getYCenter();
	}
	
	public void interact() {
		if (EZInteraction.isKeyDown(move_key)) {
			img.moveForward(4);
		}
	}
	
	
}
