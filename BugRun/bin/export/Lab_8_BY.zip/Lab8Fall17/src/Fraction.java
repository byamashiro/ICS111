
public class Fraction {
	// Member variables
	int numerator;
	int denominator;
	float value;
	
	
	// Constructor
	public Fraction(int a, int b) {
		numerator = a;
		denominator = b;
	}
	
	// Member functions
	public float decimal() {
		value = (float) numerator / denominator; // type casting
		return value;
	}
	
	public void print() {
		System.out.print(numerator + "/" + denominator + " = " + decimal() + "\n");
	}
}
