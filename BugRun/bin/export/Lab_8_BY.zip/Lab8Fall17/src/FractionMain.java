
public class FractionMain {

	public static void main(String[] args) {
		// Create an array of 10 Fractions
		Fraction[] fractions = new Fraction[10];
		
		
		// Use a for loop to create Fraction objects.
		// For each fraction, the numerator would be i+1 and
		// the denominator i+2, where i is the loop variable
		for(int i =0; i<fractions.length; i++) {
			fractions[i] = new Fraction(i+1, i+2);
			fractions[i].print();
		}
		
		
		
		// Use another for loop to print for each Fraction
		// its .print() followed by "=" followed by its .decimal()

		
	}

}
