
public class RacingBugMain {

	public static void main(String[] args) {
		EZ.initialize(600, 500);
		
		// Create a bugs array
		RacingBug [] bugs = new RacingBug[3];
		
		// 1. Create 3 bug objects into the array
		bugs[0] = new RacingBug("bug.png", 50, 60, 'q');
		bugs[1] = new RacingBug("bug.png", 50, 250, 'a');
		bugs[2] = new RacingBug("bug.png", 50, 440, 'z');

	
		
		// game loop
		while(true) {
			for (int i = 0; i<bugs.length; i++) {
				// 2. call the interact method of each bug
				bugs[i].interact();
				
				
			}
		
			EZ.refreshScreen();
		}

	}

}
