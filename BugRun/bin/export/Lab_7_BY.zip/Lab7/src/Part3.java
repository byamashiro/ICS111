import java.awt.Color;
import java.io.FileReader;
import java.util.Scanner;

public class Part3 {

	public static void main(String[] args) throws java.io.IOException {
		
		EZ.initialize(500, 500);
		
		// Open a file scanner
		Scanner fs = new Scanner(new FileReader("circles.txt"));
		
		// read line count
		int count = fs.nextInt(); // how many items we to read
		
		// create an EZCircle array
		EZCircle[] circArr = new EZCircle[count];
		
		// write a for loop that
		for (int i=0; i<count; i++) {
			int x = fs.nextInt(); // reads 3 integer values from the file x, y, radius
			int y = fs.nextInt();
			int r = fs.nextInt();
			
			circArr[i] = EZ.addCircle(x, y, 2*r, 2*r, Color.red, true); // creates a circle with x, y, 2*radius, 2*radius, saves to i cell of array
		}
		
		fs.close();
		// close file
		
		while(true) {
			// check for button press
			int x = EZInteraction.getXMouse();
			int y = EZInteraction.getYMouse();
			
			if (EZInteraction.wasMouseLeftButtonPressed()){
				for (int i = 0; i< circArr.length; i++) {
						for (int j = 0; j<circArr.length; j++) {
								circArr[j].setColor(Color.black);
						}
				}
			} else if (EZInteraction.wasMouseLeftButtonReleased()){
				for (int i = 0; i< circArr.length; i++) {
					for (int j = 0; j<circArr.length; j++) {
							circArr[j].setColor(Color.red);
					}
				}
			}
				// set color of all circles black
			
			// check for button release
			
				// set color of all circles red
			
			EZ.refreshScreen();
		}
	}

}
