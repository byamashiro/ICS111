import java.awt.Color;
import java.io.FileReader;
import java.util.Scanner;

public class Challenge {

	public static void main(String[] args) throws java.io.IOException {
		EZ.initialize(500, 500);
		
		// Open a file scanner
		Scanner fs = new Scanner(new FileReader("shapes.txt"));

			
		

	}

}
