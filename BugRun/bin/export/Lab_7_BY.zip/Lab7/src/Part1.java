import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Part1 {

	public static void main(String[] args)  throws java.io.IOException {
		Scanner fileScanner = new Scanner(new FileReader("votes.txt")); // read in votes.txt
		String[] namesArr = {"Robert", "Joice", "Phoebe", "Bella", "Zack"}; // an array with a sequence of names
		int[] voteArr = new int[5]; // an int array of the same length as names array
		
		int i = 0; // initialize a counter
		while(fileScanner.hasNext()) { // run until the element that has no following elements
			String s = fileScanner.next(); // scan through strings
			
			if (s.equals ("Robert")) { // if the string is "Robert", add 1 vote to the respective vote array element
				voteArr[0] += 1;
			} else if (s.equals ("Joice")) {
				voteArr[1] +=1;
			} else if (s.equals ("Phoebe")) {
				voteArr[2] +=1;
			} else if (s.equals ("Bella")) {
				voteArr[3] +=1;
			} else if (s.equals ("Zack")) {
				voteArr[4] +=1;
			}
						
			i++; // increment by 1
		}
		
		for (int j = 0; j<voteArr.length; j++) {
			System.out.println(namesArr[j] + " - " + voteArr[j] + " votes"); // print the name an the respective tally of votes for each person
		}

	}

}

/*
String results;
int bella = 0;
int phoebe = 0;

while(scan.hasNext()) {
	results = scan.next();
	switch(results) {
	
	case "Bella" :
		bella++;
		break;
		
	case "Phoebe" :
		phoebe++;
		break;
	}
}
*/
