import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
// some things are missing to make this code read files

public class Part2 {

	public static void main(String[] args)  throws java.io.IOException {
		// Open a file scanner
		Scanner fs = new Scanner(new FileReader("products.txt")); // read in the products
		
		// read line count
		int count = fs.nextInt(); // how many items we to read
		
		// create three arrays: product, quantity, price
		String[] product = new String[count]; // initialize a string array for the amount of counts read in
		int[] quantity = new int[count];
		float[] price = new float[count];
		float total = 0; // initialize a float variable for the total
		
		// for loop to read each line into the i-th cell of the 3 arrays
		for (int i = 0; i<count; i++) {
			product[i] = fs.next(); // read in the first column element as a string
			quantity[i] = fs.nextInt(); // ... as an int
			price[i] = fs.nextFloat(); // ... as a float
			
			System.out.println(product[i] + " - " + (quantity[i] * price[i])); // print the product name and its cost (price * quantity)
			
			total += quantity[i] * price[i]; // add the cost for one product to the total
		}
		
		System.out.println("===========");
		System.out.println("Total: " + total); // print the total
		
		fs.close(); // close file

	}

}
